const grid = document.getElementById("iconGrid");
const categoryRow = document.getElementById("categoryRow");
const emptyState = document.getElementById("emptyState");
const heroSearch = document.getElementById("heroSearch");
const librarySearch = document.getElementById("librarySearch");
const toast = document.getElementById("toast");
const iconModal = document.getElementById("iconModal");
const loginModal = document.getElementById("loginModal");

let activeCategory = "All";
let selectedIcon = null;

const categories = ["All", ...new Set(ICONS.map(i => i.category))];

function renderCategories() {
  categoryRow.innerHTML = categories.map(c =>
    `<button class="category-btn ${c === activeCategory ? "active" : ""}" data-category="${c}">${c}</button>`
  ).join("");
  categoryRow.querySelectorAll("[data-category]").forEach(btn => {
    btn.addEventListener("click", () => {
      activeCategory = btn.dataset.category;
      renderCategories();
      renderIcons(getSearchTerm());
    });
  });
}

function getSearchTerm() {
  return (librarySearch.value || heroSearch.value || "").trim().toLowerCase();
}

function renderIcons(term = "") {
  const filtered = ICONS.filter(icon => {
    const categoryMatch = activeCategory === "All" || icon.category === activeCategory;
    const haystack = [icon.name, icon.category, ...icon.tags].join(" ").toLowerCase();
    return categoryMatch && (!term || haystack.includes(term));
  });

  grid.innerHTML = filtered.map(icon => `
    <button class="icon-card" data-icon="${icon.id}">
      <div class="icon-visual">${icon.svg}</div>
      <div>
        <div class="icon-name">${icon.name}</div>
        <div class="icon-category">${icon.category}</div>
      </div>
    </button>
  `).join("");

  emptyState.classList.toggle("hidden", filtered.length !== 0);

  grid.querySelectorAll("[data-icon]").forEach(card => {
    card.addEventListener("click", () => openIcon(card.dataset.icon));
  });
}

function openIcon(id) {
  selectedIcon = ICONS.find(i => i.id === id);
  if (!selectedIcon) return;
  document.getElementById("detailPreview").innerHTML = selectedIcon.svg;
  document.getElementById("detailCategory").textContent = selectedIcon.category.toUpperCase();
  document.getElementById("detailName").textContent = selectedIcon.name;
  document.getElementById("detailDescription").textContent = selectedIcon.description;
  document.getElementById("detailTags").innerHTML = selectedIcon.tags.map(t => `<span class="tag">${t}</span>`).join("");
  document.getElementById("detailSpecs").textContent = "24×24 / 2px / currentColor";
  document.getElementById("detailCode").textContent = selectedIcon.svg;
  iconModal.classList.remove("hidden");
}

function closeModal(el) {
  document.getElementById(el)?.classList.add("hidden");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(showToast.t);
  showToast.t = setTimeout(() => toast.classList.add("hidden"), 1900);
}

async function copySelected() {
  if (!selectedIcon) return;
  try {
    await navigator.clipboard.writeText(selectedIcon.svg);
    showToast("SVG copied");
  } catch {
    showToast("Copy not available in this browser");
  }
}

function downloadSelected() {
  if (!selectedIcon) return;
  const blob = new Blob([selectedIcon.svg], {type:"image/svg+xml"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${selectedIcon.id}.svg`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("SVG downloaded");
}

heroSearch.addEventListener("input", () => {
  librarySearch.value = heroSearch.value;
  renderIcons(heroSearch.value.trim().toLowerCase());
});
librarySearch.addEventListener("input", () => {
  heroSearch.value = librarySearch.value;
  renderIcons(librarySearch.value.trim().toLowerCase());
});

document.addEventListener("keydown", (e) => {
  if (e.key === "/" && !["INPUT","TEXTAREA"].includes(document.activeElement.tagName)) {
    e.preventDefault();
    heroSearch.focus();
  }
  if (e.key === "Escape") {
    iconModal.classList.add("hidden");
    loginModal.classList.add("hidden");
  }
});

document.querySelectorAll("[data-close]").forEach(btn => {
  btn.addEventListener("click", () => closeModal(btn.dataset.close));
});

document.getElementById("copySvg").addEventListener("click", copySelected);
document.getElementById("downloadSvg").addEventListener("click", downloadSelected);

document.getElementById("openLogin").addEventListener("click", () => {
  loginModal.classList.remove("hidden");
});

document.getElementById("loginForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const fd = new FormData(e.currentTarget);
  const beanId = fd.get("beanId");
  localStorage.setItem("uasset_demo_bean", beanId);
  loginModal.classList.add("hidden");
  document.getElementById("openLogin").innerHTML = `<span class="bean-dot"></span>${beanId}`;
  showToast(`Signed in as ${beanId}`);
  e.currentTarget.reset();
});

document.getElementById("proBtn").addEventListener("click", () => showToast("Pro checkout comes after the library is ready."));

renderCategories();
renderIcons();

const savedBean = localStorage.getItem("uasset_demo_bean");
if (savedBean) {
  document.getElementById("openLogin").innerHTML = `<span class="bean-dot"></span>${savedBean}`;
}
